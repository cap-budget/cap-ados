# CAP Ados

Application de budget mobile-first, indépendante de CAP Budget. HTML, CSS et JavaScript sans compilation. Données locales uniquement, sans connexion bancaire ni paiement actif.

## Fonctionnalités

- Argent reçu et dépenses par mois, disponible et estimation par jour restant.
- Envies : création, modification du nom et du prix, suivi de l’épargne et suppression avec confirmation.
- L’épargne des envies est un suivi indicatif de sommes déjà séparées du disponible. Elle n’est pas débitée automatiquement.
- Une victoire anti-gaspi par jour ; les dépenses évitées ne gonflent pas le solde.
- Trophées permanents : premier budget non nul, premier objectif, cinq jours de victoires.
- Simulation d’achat sans modifier le budget.
- Présentation Pro provisoire, sans paiement ou verrouillage.

## Fichiers à déposer dans le dépôt cap-ados

Décompressez l’archive puis déposez le contenu du dossier cap-ados à la racine du dépôt : index.html, style.css, app.js et ce README. Le dossier tests contient les vérifications automatisées ; inutile pour l’hébergement.

Aucune configuration Sites, aucun identifiant de projet, aucune donnée personnelle et aucune clé ne sont inclus dans cette archive.

## Essai local

Ouvrez index.html dans un navigateur. Pour un stockage local stable, servez plutôt le dossier avec un serveur HTTP local, par exemple `python -m http.server 8000`, puis ouvrez http://localhost:8000.

Les données sont liées au navigateur et à l’adresse du site. Une copie sur un autre hébergement ne récupère pas automatiquement les données du prototype. Effacer le stockage du navigateur les supprime.

La police Plus Jakarta Sans est chargée depuis Google Fonts ; une police système prend le relais sans réseau.

## Vérifications

Depuis le dossier cap-ados, exécutez `node tests/app.test.cjs`. Les tests utilisent un DOM simulé et couvrent les calculs, les projets, les trophées et le rechargement ; ils ne remplacent pas un contrôle visuel sur téléphone.

## Structure du stockage

Clé localStorage : `cap-ados-monthly-v1`. Structure : months, goals, victories, achievements. Les montants sont stockés en centimes. Les anciens budgets et projets sont conservés lors de l’ajout des trophées.

## Raccourci et ancien stockage

Le bouton « + 5 € » augmente le suivi d’une épargne déjà séparée, sans dépasser le prix de l’envie et sans modifier le disponible. L’ancien format `cap_ados_data` est importé seulement si la clé actuelle est absente. Les anciens compteurs de victoires sont conservés à part : leur script ne stockait pas les dates, donc ils ne comptent pas pour le trophée des cinq jours distincts. La clé d’origine reste intacte. Les données invalides sont ignorées ; les montants 60/15 et le projet exemple ne sont jamais créés comme de vraies données par défaut.

## Défi hebdomadaire et démonstration Pro

La semaine va du lundi au dimanche selon l’heure locale de l’appareil. Trois victoires datées dans cette semaine rendent le défi validable. Une validation rapporte 50 XP une seule fois pour cette semaine, conservés au rechargement, sans modifier le solde. Le défi suivant repart à zéro ; l’XP cumulé reste acquis. Les anciens compteurs non datés ne contribuent pas à ce défi. La fenêtre Pro présente un parcours de démonstration : aucun appel Stripe, aucun débit et aucune activation Pro.
